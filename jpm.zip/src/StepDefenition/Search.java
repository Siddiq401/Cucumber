package StepDefenition;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.en.Given;

public class Search {

	List<String> latestHeadlinesFromGuadrian = new ArrayList<String>();
	static WebDriver driver;

	@Given(value = "the user extracts the latest headlines from the guradian website")
	public void guardianNews() {
		System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\libs\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		WebDriverWait wait = new WebDriverWait(driver, 60);
		driver.manage().window().maximize();
		driver.get("https://www.theguardian.com/tone/news");
		driver.findElement(By.xpath("//button[@data-link-name='first-pv-consent : agree']")).click();

		List<WebElement> headlineElements = driver.findElements(By.xpath("//div[@class='fc-item__container']//h3//a"));
		for (WebElement currentElement : headlineElements) {
			latestHeadlinesFromGuadrian.add(currentElement.getText());
		}
		System.out.println(latestHeadlinesFromGuadrian);
	}

	List<String> matchingHeadlinesFromBBC = new ArrayList<String>();

	@Given(value = "the user searches in google for the same headline in other reputable sources like BBC")
	public void BBCNews() {

		for (String currentGuradianHeadline : latestHeadlinesFromGuadrian) {
			driver.navigate().to("https://www.google.com");
			driver.findElement(By.xpath("//input[@name='q']")).sendKeys(currentGuradianHeadline + " BBC.com");

			WebElement ele = driver
					.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@aria-label='Google Search']"));
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", ele);

			matchingHeadlinesFromBBC.add(driver.findElement(By.xpath("(//h3)[1]")).getText());
		}
	}

	@Given(value = "the user should find matching articles")
	public void compare() {

		for (int i = 0; i < matchingHeadlinesFromBBC.size(); i++) {

			System.out.println("***********************************************************");
			List<String> headlineFromGuardian = removeCommonStopWordsAndConvertToList(
					latestHeadlinesFromGuadrian.get(i));
			List<String> headlineFromBBC = removeCommonStopWordsAndConvertToList(matchingHeadlinesFromBBC.get(i));

			int NumberOfWordMatch = 0;
			for (String currentWord : headlineFromGuardian) {
				if (headlineFromBBC.contains(currentWord)) {
					NumberOfWordMatch++;
				}
			}

			System.out.println("Headline From Guardian: " + latestHeadlinesFromGuadrian.get(i));
			System.out.println("Equivalent Search from google: " + matchingHeadlinesFromBBC.get(i));
			System.out.println("Number of meaninful keyword match: " + NumberOfWordMatch);
			if (NumberOfWordMatch >= 3) {
				System.out.println("News Valid");
			} else {
				System.out.println("News not found in other sources");
			}

		}
		driver.quit();

	}

	private List<String> removeCommonStopWordsAndConvertToList(String sentence) {

		sentence = sentence.replace("a", "");
		sentence = sentence.replace("as", "");
		sentence = sentence.replace("was", "");
		sentence = sentence.replace("is", "");
		sentence = sentence.replace("of", "");
		sentence = sentence.replace("  ", " ").replace("  ", " ").replace("  ", "");
		List<String> wordList = new ArrayList<>();
		String[] tempArray = sentence.split(" ");
		for (String currentEle : tempArray) {
			wordList.add(currentEle.trim());
		}

		return wordList;
	}

}
